
#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    int arr[size],itr;
    //array's input
    for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);
    int key;
    scanf("%d",&key);
    //Binary searching
    int start=0,end=size-1,mid;
    int count=0;
    while(start<=end)
    {
        mid = (start+end)/2;
        if(arr[mid]==key)
            break;
        else{
           if(arr[mid]<key)
                start = mid+1;
           else
            end = mid-1;
        }
        count++;
    }
    if(arr[mid]==key)
        printf("Element found");
    else
        printf("Not found");
   printf("%d",count);



    return 0;
}
