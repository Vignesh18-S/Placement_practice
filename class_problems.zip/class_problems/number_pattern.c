#include<stdio.h>
int main()
{
  int num,row,col;
  scanf("%d",&num);
  //int value=2;
  char value='A';
  for(row=1;row<=num;printf("\n"),row+=1)
  {
      for(col=1;col<=row;col+=1){
         printf(" %c ",value);
         value+=1;
      }
  }

}
