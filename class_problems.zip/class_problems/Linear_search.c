#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    int arr[size],itr;
    //array's input
    for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);
    int key;
    scanf("%d",&key);
    //linear
    for(itr=0;itr<size;itr+=1)
    {
        if(arr[itr]==key)
            break;
    }
    if(itr<size)
        printf("Element found at %d",itr+1);
    else
        printf("Not found");



    return 0;
}
