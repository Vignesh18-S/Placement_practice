
#include<stdio.h>
int main()
{
   int row,col;
   scanf("%d%d",&row,&col);
    int arr[row][col];
   int i,j;
   for(i=0;i<row;i+=1)
   {
       for(j=0;j<col;j+=1)
          scanf("%d",&arr[i][j]);
   }

   if(row!=col)
     printf("Not");

   else
   {


    //identity or not
    for(i=0;i<row;i+=1)
    {
        for(j=0;j<col;j+=1)
        {
            if(i==j){
               if(arr[i][j]!=1)
                    break;
            }

            else{
                if(arr[i][j]!=0)
                    break;
            }
        }
        if(j<col)
            break;

    }
    if(i<row)
        printf("Not identity matrix");
    else
        printf("Identity matrix");

   }



    return 0;
}

