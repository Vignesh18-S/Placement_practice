#include<stdio.h>
void sum_using_update(int *num , int size)
{
    int itr,sum=0;
    for(itr=0;itr<size;itr+=1)
      sum += num[itr];

    for(itr=0;itr<size;itr+=1)
    {
        num[itr] = sum - num[itr];
    }
}
int main()
{
     int size;
     scanf("%d",&size);
     int arr[size],itr;
     for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);

     sum_using_update(arr,size);
     for(itr=0;itr<size;printf("%d ",arr[itr]),itr+=1);
    return 0;
}
