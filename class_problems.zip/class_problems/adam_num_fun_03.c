#include<stdio.h>
//square
int square(int n)
{
    return n*n;

}
//reverse
int reverse(int n)
{
    int rev=0;
    while(n!=0)
    {
        rev = rev*10+(n%10);
        n/=10;
    }
    return rev;

}
int main()
{
    int num;
    scanf("%d",&num);//12
    int sqr_num = square(num); //144
    int rev_num = reverse(num); //21
    int sqr_rev_num = square(rev_num);//441
    int rev_sqr_rev_num = reverse(sqr_rev_num);//144

   // printf("%d %d %d %d",sqr_num,rev_num,sqr_rev_num,rev_sqr_rev_num);

    if(sqr_num == rev_sqr_rev_num) //false
        printf("Adam number");
    else
        printf("Not");

}


