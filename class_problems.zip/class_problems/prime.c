#include<stdio.h>
int main()
{
    int num,itr;
    scanf("%d",&num); //prime or not
    if(num==1 || num==2 || num==3)
        printf("Prime");
    else{
    int count=0,count1=0;
    for(itr=2;itr<=num/2;itr+=1)  //num/2 -->100 --> 50
    {
        count1++;
       if(num%itr==0)
            count++;
    }
    printf("%d\n",count1);
    if(count==0)
        printf("Prime");
    else
        printf("Not");
}

    return 0;
}
