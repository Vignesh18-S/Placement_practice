#include<stdio.h>
int main()
{
    int num;
    scanf("%d",&num);
    //sum of digit
    int temp1=num;
    int sum=0;
    while(num!=0)
    {
        sum+=(num%10);
        num/=10;
    }
    //number reverse
    int temp =sum;
    int rev=0;
    while(temp!=0)
    {
        rev = rev*10 + (temp%10);
        temp/=10;
    }
    if(sum*rev == temp1)
        printf("Magic");
    else
        printf("Not");


  return 0;
}
