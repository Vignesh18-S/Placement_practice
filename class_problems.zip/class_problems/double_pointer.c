#include<stdio.h>
int main()
{
    int a=10;
    int *ptr;
    ptr=&a;
    printf("%d\n",*ptr);
    int **ptr1;
    ptr1=&ptr;
    printf("%u\n",&a);
    printf("%p",*ptr1);
    return 0;
}

