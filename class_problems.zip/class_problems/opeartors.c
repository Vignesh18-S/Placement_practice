#include<stdio.h>
int main()
{
   /* int a=22;
    char var='Z';
    double cpa = 7.89;
    /*
    //sizeof()
    printf("size of a %d\n",sizeof(a));
    printf("size of var %d\n",sizeof(var));
    printf("size of cpa %d\n",sizeof(cpa));


    //type casting
    float cpa1 = 9.836;
    printf("%.1f",cpa1);
    //printf("%d",(int)cpa1);*/
    int a=5;
    printf("%d",(a++ + ++a));
    return 0;
}
