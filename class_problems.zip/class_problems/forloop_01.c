
#include<stdio.h>
int main()
{
    int num;
    scanf("%d",&num);
   /* int itr;
    printf("1 %d ",num);
    for(itr=2;itr<=num/2;itr+=1)
    {
        if(num%itr==0)
            printf("%d ",itr);
    }*/
    int sum=1,itr;
    for(itr=2;itr<=num/2;itr+=1)
    {
        if(num%itr==0)
          sum+=itr;
    }
    //sum
    if(num==sum)
        printf("Perfect");
    else if(sum > num)
        printf("Abundant");
    else
        printf("Deficient");


  return 0;
}
