#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
   /* int itr=1;
    while(itr<=n)
    {
        printf("%d ",itr);
        itr+=1;
    }
    */
    int itr;  //11<=10
    for(itr=11;itr<=n;printf("%d ",itr),itr+=1);

   /* int itr=11;  //exit   false termination
    do
    {
        printf("%d ",itr);
        itr+=1;
    }while(itr<=n); //11<=10*/


    return 0;
}
