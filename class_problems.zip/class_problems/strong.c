#include<stdio.h>
int main()
{
    int num;
    scanf("%d",&num); //145
    int temp =num;   //temp=145
    int fact,sum=0;
    while(num!=0)
    {
        fact=1;
        for(int itr=1;itr<=(num%10);itr+=1)
            fact*=itr;
        num/=10;
        sum+=fact; //1
    }

    if(sum==temp)
        printf("Strong");
    else
        printf("Not");
    return 0;
}
