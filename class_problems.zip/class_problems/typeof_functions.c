
#include<stdio.h>
/*
//without return and without parameter
void sum_of_two();
int main()
{
   sum_of_two();
   printf("\nEnd of the program");

   return 0;
}
void sum_of_two()
{
    int num1,num2;
    scanf("%d%d",&num1,&num2);
    int sum =num1+num2;
    printf("sum  is : %d",sum);

}

//with return and without parameter
int sum_of_two();
int main()
{
   int num = sum_of_two();
   printf("%d",num);
   printf("\nEnd of the program");

   return 0;
}
int sum_of_two()
{
    int num1,num2;
    scanf("%d%d",&num1,&num2);
    int sum =num1+num2;
    return sum;

}

*/

//without return and parameter
int sum_of_two(int,char);
int main()
{
    int num1;
    char ch;
    return 0;
    scanf("%d %c",&num1,&ch); //10
    sum_of_two(num1,ch);

}

int sum_of_two(int a,char b)
{
    printf("%d ",a);
    printf("%c ",b);
    return 0;

}






