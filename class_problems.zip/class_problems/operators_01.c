
#include<stdio.h>
int main()
{
    int a=30,b=20;

   /*
    // comparison or relational
   printf("%d\n",a==b);
    printf("%d\n",a!=b);
    printf("%d\n",a>b);
    printf("%d\n",a>=b);
    printf("%d\n",a<b);
    printf("%d\n",a<=b);*/

    /*
    //assignmnet ops
    a=b; //a=20
    printf("%d\n",a);
    printf("%d\n",b);
    a+=b;
    printf("%d",a);

    */
   /*
    //Bitwise ops


    a=10 ;
    b=2;
    printf("%d",a<<b);
    */
    //(a>b)?printf("A is greater"):printf("B is greater");


    printf("%d",-a);

   return 0;
}


