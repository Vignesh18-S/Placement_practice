
#include<stdio.h>
int main()
{
    int num;
    scanf("%d",&num);
    int rev=0;
    while(num!=0) //12345
    {
        rev=(10*rev)+num%10; //54321
        num/=10;
    }
    printf("%d",rev);

    return 0;
}
