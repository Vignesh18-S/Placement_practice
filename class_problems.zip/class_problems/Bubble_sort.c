
#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    int arr[size],itr;
    for(itr=0;itr<size;itr+=1)
    {
        scanf("%d",&arr[itr]);
    }

    //bubble sort algorithm (ascending order)
    int pass,com,temp,flag;
    for(pass=0;pass<=size-2;pass+=1) //no of passes
    {
        flag=0;
        for(com=0;com<=size-2-pass;com+=1) // for comparison count (size-1)
        {
            if(arr[com] > arr[com+1]) //if it is true  num1 > num2  note:for descending order charge "<"
            {
               temp = arr[com];
               arr[com] = arr[com+1];
               arr[com+1] = temp;         //num1 < num2
               flag=1;
            }
        }
        if(flag==0)
            break;
    }

     for(itr=0;itr<size;itr+=1)
        printf("%d ",arr[itr]);

    return 0;
}
