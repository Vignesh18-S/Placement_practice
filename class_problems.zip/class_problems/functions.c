#include<stdio.h>
int sum_of_five(int,int,int,int,int); //declaration
int main()
{
    int num1,num2,num3,num4,num5;
    scanf("%d%d%d%d%d",&num1,&num2,&num3,&num4,&num5);

    printf("%d",sum_of_five(num1,num2,num3,num4,num5)); //func call


}
int sum_of_five(int a,int b,int c,int d,int e) //definition
{
     int sum = (a+b+c+d+e);
     return sum;

}


