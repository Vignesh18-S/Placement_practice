#include<stdio.h>
int main()
{
    int num,row,col,space,star;
    scanf("%d",&num);
    //original
    for(row=1;row<num;printf("\n"),row+=1)
    {
        //star
        for(star=1;star<=row;star+=1)
        {
            if(star==1 || star==row)
              printf(" * ");
            else
              printf("   ");
        }

        //space
        for(space=1;space<=(num-row)*2;space+=1)
            printf("   ");

       //star
        for(star=1;star<=row;star+=1)
        {
            if(star==1 || star==row)
              printf(" * ");
            else
              printf("   ");
        }
    }
     //mirror
     for(row=num;row>=1;printf("\n"),row-=1)
    {
        //star
        for(star=1;star<=row;star+=1)
        {
            if(star==1 || star==row)
              printf(" * ");
            else
              printf("   ");
        }
        //space
        for(space=1;space<=(num-row)*2;space+=1)
            printf("   ");

       //star
        for(star=1;star<=row;star+=1)
        {
            if(star==1 || star==row)
              printf(" * ");
            else
              printf("   ");
        }

    }

    return 0;
}
