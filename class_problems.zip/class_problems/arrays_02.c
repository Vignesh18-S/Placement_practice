#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size); //6
    int arr[size],itr;
    //input loop
    for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);

    //process odd & even count
    int odd=0,even=0;          // 1 2 3 4 5 6  --> value arr[itr]
    for(itr=0;itr<size;itr+=1) // 0 1 2 3 4 5 6 --> index  itr
    {
        if(arr[itr]%2!=0) //arr[1]%2!=0
           odd++;//3
        else
            even++; //3

    }
    printf("%d %d",odd,even);

    return 0;
}

