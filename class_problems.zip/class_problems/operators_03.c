#include<stdio.h>
int main()
{
    /*
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    if(a>b)
    {
       if(a>c)
            printf("A is greater");
       else
           printf("C is greater");
    }
    else{
            if(b>c)
              printf("B is greater");
             else printf("C is greater");

    }
    if((a>b)&&(a>c))
        printf("A");
    else if ((b>a)&&(b>c))
        printf("B");
    else
        printf("C");
        */

    int year;
    scanf("%d",&year);
   /* if(year%4==0)
    {
       if(year%100==0)
       {
           if(year%400==0)
               printf("Leap year");
           else
               printf("Not leap");
       }
       else printf("Leap year"); //2008
    }
    else
        printf("Not leap");*/
        if((year%4==0 && year%100!=0) || (year%400==0))
            printf("Leap");
        else printf("Not");

}
