#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a); //10
    int *ptr;
    ptr = &a;
    *ptr+=10;
    printf("a is %d\n",a); //10
    printf("pointer value %d\n",*ptr); //20
    /*printf("ptr value %u\n",ptr);
    printf("a memory address %u",&a);
    printf("ptr moemory address %u",&ptr);*/
}
