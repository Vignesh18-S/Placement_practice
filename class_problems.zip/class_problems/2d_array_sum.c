#include<stdio.h>
int main()
{
    int row,col,i,j;
    scanf("%d%d",&row,&col);
    int arr[row][col];
    //read input of 2d
    for(i=0;i<row;i+=1)
    {
        for(j=0;j<col;j+=1)
            scanf("%d",&arr[i][j]);
    }

    // process
    int sum_outer=0,sum_left=0,sum_right=0;
    for(i=0;i<row;i+=1)
    {
        for(j=0;j<col;j+=1)
        {
            if(i==0 || i==row-1 || j==0 || j==col-1) //outer
                 sum_outer+=arr[i][j];

            if(i==j)                                //left diagonal sum
                 sum_left+=arr[i][j];

            if(i+j == row-1)                        //right dia sum
                 sum_right+=arr[i][j];
        }
    }
    printf("Outer sum  is %d\nSum of left diagonal %d\nSum of right diagonal %d",sum_outer,sum_left,sum_right);

    return 0;
}
