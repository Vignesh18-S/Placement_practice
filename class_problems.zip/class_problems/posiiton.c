#include<stdio.h>
int main()
{
    int num;

    scanf("%d",&num);
    int pow=1;
    int temp =num;
    //maximum power value
    while(num>=9)
    {
        pow*=10;
        num/=10;
    }
    //digit seggregation

    while(pow!=0)
    {
      //printf("%d ",temp/pow);
      if(temp/pow)%2!=0)
          printf("%d ",temp/pow);
      temp%=pow;
      pow/=10;
    }
    return 0;
}
