#include<stdio.h>
int main()
{
  /*  int n;
    scanf("%d",&n); //10
    int itr;
    itr=1; //initial  1 2 3 4 5 6 7 8 9 10 11
    while(itr<=n) //3<=10
    {
       if(itr%2==0)
          printf("%d ",itr);

       itr=itr+1;
    }*/

    int n;
    scanf("%d",&n);
    int itr=1,even=0,odd=0;
    while(itr<=n)  //1<=10
    {
        //process
        if(itr%2==0) //1%2==0 false
        {
            even+=1; //even=even+1
        }
        else
        {
            odd+=1;
        }
        itr+=1;

    }
    printf("Even = %d\nOdd = %d",even,odd);

    return 0;
}
