#include<stdio.h>
int main()
{
    int num,itr;
    scanf("%d",&num); //prime or not
    if(num==1 || num==2 || num==3)
        printf("Prime");
    else{
            int itr,count=0;
            for(itr=2;itr<=num/2;itr+=1)
            {
                count++;
                if(num%itr==0)
                     break;

            }
            printf("%d\n",count);
            if(itr<=num/2)
              printf("Not prime");
            else printf("Prime");


      }

    return 0;
}

