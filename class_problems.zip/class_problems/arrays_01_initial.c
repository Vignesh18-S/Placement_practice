#include<stdio.h>
int main()
{
    /*
    int arr[5]={10,20,30,40,50}; //initialize
    int itr;
    for(itr=0;itr<5;itr+=1)
        printf("%d ",*(arr+itr));
    */
    int size;
    scanf("%d",&size); //60
    int arr[size]; //declare
    int itr;
    for(itr=0;itr<size;itr+=1)
        scanf("%d",&arr[itr]); //0 001

        //process
    for(itr=0;itr<size;itr+=1)
    {
        if(arr[itr]%2!=0)
             printf("%d ",arr[itr]);
    }


    return 0;
}
