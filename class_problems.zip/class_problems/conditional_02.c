#include<stdio.h>
int main()
{
   /* int mark;
    scanf("%d",&mark);
    if(mark>=0 && mark<=100)
    {
       if(mark>=90)
        printf("O grade");
    else if(mark>=80)
        printf("A+ grade");
    else if(mark>=70)
        printf("A grade");
    else if(mark>=60)
        printf("B+ grade");
    else if(mark>=50)
        printf("B grade");
    else if(mark>=45)
        printf("C grade");
    else
        printf("U");
    }
    else
        printf("Mark is invalid");
    */
    int num1,num2;
    char oper;
    scanf("%d%d %c",&num1,&num2,&oper);
    if(oper=='+')
        printf("Sum is %d",num1+num2);
    else if(oper=='-')
        printf("Difference is %d",num1-num2);
    else if(oper=='*')
        printf("Product is %d",num1*num2);
    else if(oper=='/')
        printf("Quotient is %d",num1/num2);
    else if(oper=='%')
        printf("Reminder is %d",num1%num2);
    else
        printf("Invalid operation");

    return 0;
}
