#include<stdio.h>
#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size); //6
    int arr[size],itr;
    for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);
    //right rotation
    int temp;
    int count;
    scanf("%d",&count); //400%size
    if(count%5==0)

    for(int c=1;c<=count%size;c+=1)
    {
        temp=arr[size-1];
    for(int itr=size-1;itr>0;itr--)
        arr[itr] = arr[itr-1];
    arr[0] = temp;
    }

    for(itr=0;itr<size;printf("%d ",arr[itr]),itr+=1);


    return 0;
}



