#include<stdio.h>
int main()
{
    int num;
    scanf("%d",&num);
    int odd=0,even=0,zero=0;  //530506
    while(num!=0) // 0!=0
    {
      if(num%10==0)
        zero++;
      else if((num%10)%2!=0)
        odd++;
      else
         even++;
      num=num/10;

    }
    printf("Odd is %d\n even is %d\nzero are %d",odd,even,zero);

    return 0;
}
