#include<stdio.h>
int main()
{
   /*float cgpa;
   int width; //5

    scanf("%d%f",&width,&cgpa); //9.8
    printf("This is my cgpa %010.*f",width,cgpa);

    double cgpa;
    scanf("%lf",&cgpa);
    printf("%.16lf",cgpa);*/

    int a=5;
    printf("%d\n",a--);
    printf("%d",a);
}


