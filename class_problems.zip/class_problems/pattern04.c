#include<stdio.h>
int main()
{
    int num,row,col;
    scanf("%d",&num);

    for(row=1;row<=num;printf("\n"),row+=1)
    {
        for(col=1;col<=num;col+=1)
        {
            if(row==col || row+col == num+1 || row==1 || row==num || col==1 || col==num)
                printf(" * ");
            else printf("   ");
        }

    }
    return 0;
}
