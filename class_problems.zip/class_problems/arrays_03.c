#include<stdio.h>
#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size); //6
    int arr[size],itr;
    for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);
    //reverse
    int start=0,end=size-1,temp;
    while(start<end)
    {
        temp =arr[start];
        arr[start] = arr[end];
        arr[end]=temp;

        start++;
        end--;
    }
        //display
        for(itr=0;itr<size;printf("%d ",arr[itr]),itr+=1);


    return 0;
}


