/*
//call by value
#include<stdio.h>
int swap(int a,int b) //formal arguments
{
    int temp;
    temp =a;
    a=b;
    b=temp;
    printf("%d %d\n",a,b);

}
int main()
{
    int num1,num2;
    scanf("%d%d",&num1,&num2); //10 20
    swap(num1,num2); //Actual arguments
    printf("after swap %d %d\n",num1,num2);
    return 0;
}*/
#include<stdio.h>

//call by reference
int swap(int *a ,int *b) //formal arguments
{

    int temp;
    temp =*a;
    *a=*b;
    *b=temp;
    printf("%d%d\n",*a,*b);

}
int main()
{
    int num1,num2;
    scanf("%d%d",&num1,&num2); //10 20
    swap(&num1,&num2); //Actual arguments
    printf("\nAfter a swap %d %d ",num1,num2);

    return 0;
}


