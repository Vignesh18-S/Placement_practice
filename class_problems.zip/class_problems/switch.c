#include<stdio.h>
int main()
{
   int day;
   scanf("%d",&day); //1 2 3 4 5 6 7
   switch(day)
   {
      case 1:printf("Sunday\n");break;
      case 2:printf("Monday\n");break;
      case 3:printf("Tuesday\n");break;
      default:printf("Invalid\n");
      case 4:printf("wednesday\n");break;
      case 5:printf("Thursday\n");break;
      case 6:printf("Friday\n");break;
      case 7:printf("Saturday\n");break;

   }

}
