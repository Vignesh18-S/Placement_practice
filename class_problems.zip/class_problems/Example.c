#include<stdio.h>
int main(){
   int num =-12345;
   if(num<=0)
    num=-1*num;
   while(num)
   {
       printf("%d ",num%10);
       num/=10;

   }
}
