//2 dimensional arrays
#include<stdio.h>
int main()
{
    // int arr[3][3] = {{1,2,3},{4,5,6},{7,9,8}}; //initialization
    int row,col;
    scanf("%d%d",&row,&col);
    int arr[row][col],i,j;
    //read
    for(i=0;i<row;i+=1)
    {
        for(j=0;j<col;j+=1)
             scanf("%d",&arr[i][j]);
    }
    //write
    int sum;

    for(i=0;i<row;i+=1)
    {
        sum=0;
        for(j=0;j<col;j+=1)
            sum += arr[i][j];
        printf("%d ",sum);
    }
   // printf("total sum is : %d",sum);

    return 0;
}

