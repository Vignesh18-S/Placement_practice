
#include<stdio.h>
void sum_of_five(int,int,int,int,int); //declaration
int main()
{
    sum_of_five(1,2,3,4,5);
    sum_of_five(10,20,30,40,50);
    printf("Not interested\n");
    printf("Not interested\n");
    sum_of_five(23,54,76,67,89);
    printf("Later\n");
    sum_of_five(12,34,56,67,19);
    //but


   return 0;

}
void sum_of_five(int a,int b,int c,int d,int e) //definition
{
     int sum = (a+b+c+d+e);
     printf("%d\n",sum);

}


