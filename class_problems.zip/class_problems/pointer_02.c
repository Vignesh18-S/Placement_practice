#include<stdio.h>
int main()
{
    /*int a=10;
    int *ptr;
    ptr =&a;
    *(ptr+3)=256;
    printf("a is %d\n",a);
    printf("%u\n",ptr+3);
    printf("%d\n",*(ptr+3));
    printf("sizeof pointer value %d\n",sizeof(*ptr));
    printf("sizeof pointer reference %d\n",sizeof(ptr));
    */
    char ch='A';
    char *ptr;
    ptr=&ch;
    printf("%c\n",*ptr);
    printf("%u\n",ptr);
    printf("%u\n",ptr+2);
    printf("sizeof pointer value %d\n",sizeof(*ptr));
    printf("sizeof pointer reference %d\n",sizeof(ptr));

}
