#include<stdio.h>
int main()
{
   int row,col;
   scanf("%d%d",&row,&col);
    int arr[row][col];
   int i,j;
   for(i=0;i<row;i+=1)
   {
       for(j=0;j<col;j+=1)
          scanf("%d",&arr[i][j]);
   }
  // toeplitz or not

  for(i=0;i<=row-2;i+=1)
  {
      for(j=0;j<=col-2;j+=1)
      {
          if(arr[i][j] != arr[i+1][j+1])
            break;
      }
      if(j<=col-2)
        break;
  }
  if(i<=row-2)
    printf("Not a Toeplitz");
  else printf("Toeplitz");




    return 0;
}

