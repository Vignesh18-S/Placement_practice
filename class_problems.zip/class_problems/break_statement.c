#include<stdio.h>
int main()
{
   int num;
   scanf("%d",&num); //5
   int itr=1;

   start:
         printf("%d ",itr); // 1 2 3 4 5
         itr+=1; //6
         if(itr<=num) //6<=5
            goto start;

    printf("End of the program");

}
