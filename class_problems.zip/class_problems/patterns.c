
#include<stdio.h>
int main()
{
    int num,row,col;
    scanf("%d",&num);
    //box
   /* for(row=1;row<=num;printf("\n"),row+=1)
    {
        for(col=1;col<=num;col+=1)
            printf(" * ");


    }*/
    //increment
    for(row=1;row<num;printf("\n"),row+=1)
    {
        for(col=1;col<=row;col+=1)
            printf(" * ");

    }

    //decrement
    for(row=num;row>=1;printf("\n"),row-=1)
    {
        for(col=1;col<=row;col+=1)
            printf(" * ");

    }


    return 0;
}
