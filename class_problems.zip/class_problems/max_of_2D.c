
//2 dimensional arrays
#include<stdio.h>
int main()
{
    int row,col;
    scanf("%d%d",&row,&col);
    int arr[row][col],i,j;
    //read
    for(i=0;i<row;i+=1)
    {
        for(j=0;j<col;j+=1)
             scanf("%d",&arr[i][j]);
    }
 /*
    // max of 2d
    int max = arr[0][0];

    for(i=0;i<row;i+=1) // 3 3 --> 3 X
    {
        for(j=0;j<col;j+=1) //0 1 2
        {
            if(max < arr[i][j])
                max =arr[i][j];
        }
    }

  printf("Maximum of 2d %d",max);
  */

   int max;

    for(i=0;i<row;i+=1) // 2
    {
        max = arr[i][0];
        for(j=0;j<col;j+=1) //0 1 2
        {
            if(max < arr[i][j])
                max =arr[i][j];
        }
        printf("%d th maximum is %d\n",i,max);
    }


    return 0;
}

