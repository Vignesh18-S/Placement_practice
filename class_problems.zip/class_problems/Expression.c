#include<stdio.h>
int main()
{
    int a=5,b=20;
   // printf("%d",(++a + a++));
   printf("%d",(a+b)*3);
    return 0;
}

/*
//pre -> post

//post --> pre
  7     6     //13
(++a + a++)  6

  6       6   //12
(a++ + ++a)
*/
