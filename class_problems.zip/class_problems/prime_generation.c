#include<stdio.h>
int is_prime(int n)
{
    int itr;
    for(itr=2;itr<=n/2;itr+=1)
    {
        if(n%itr==0)
            return 0;
    }

    return 1;

}
int main()
{
    int start,end;
    scanf("%d%d",&start,&end); // 5 30

    int itr;
    for(itr=start;itr<=end;itr+=1) //5
    {
        if(is_prime(itr)==1)
            printf("%d ",itr); //5 7 11 13 ...29

    }

}
