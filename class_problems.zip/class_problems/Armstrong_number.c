#include<stdio.h>
#include<math.h>
int digit_count(int n)
{
    int count=0;
    while(n!=0)
    {
        count++;
        n/=10;
    }
    return count;
}
int power(int base,int expo)
{
    int res=1;
    for(int itr=1;itr<=expo;itr+=1)
        res*=base;
    return res;
}
int main() //armstrong or not
{
    int num;
    scanf("%d",&num);
    int temp=num;
    int count = digit_count(num);
    int sum=0;
    while(num!=0)
    {
        sum+=power(num%10,count);
        num/=10;
    }

    if(sum==temp)
        printf("Armstrong number");
    else
        printf("Not");




    return 0;
}
