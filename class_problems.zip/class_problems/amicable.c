#include<stdio.h>
int main()
{
    int num1,num2;
    scanf("%d%d",&num1,&num2);
    int sum1=0,sum2=0,itr;
    //num1 sum of factor
    for(itr=1;itr<=num1/2;itr+=1)
    {
        if(num1%itr==0)
          sum1+=itr;
    }
    //num2 sum of factor
    for(itr=1;itr<=num2/2;itr+=1)
    {
        if(num2%itr==0)
          sum2+=itr;
    }
     if(sum1==num2 && sum2==num1)
        printf("Amicable");
     else
        printf("Not");

    return 0;
}
