
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int a,itr;
    int *ptr = (int*)malloc(sizeof(int)*5);
   for(itr=0;itr<5;itr+=1){
      *(ptr+itr) = 10;
      printf("%d ",*(ptr+itr));

    }

    return 0;
}


//1000 1004 1008 1012 1016

