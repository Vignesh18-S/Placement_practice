#include<stdio.h>
int main()
{
    int row,col,i,j;
    scanf("%d%d",&row,&col);
    int arr[row][col];
    //read input of 2d
    for(i=0;i<row;i+=1)
    {
        for(j=0;j<col;j+=1)
            scanf("%d",&arr[i][j]);
    }
    //spiral traversal
    int left=0,right=col-1,top=0,bottom=row-1;

    while(left<=right && top<=bottom)
    {
        //print top --> left to right
    for(i=left;i<=right;i+=1)
         printf("%d ",arr[left][i]);
    top+=1;

    //print right --> top to bottom
    for(i=top;i<=bottom;i+=1)
        printf("%d ",arr[i][right]);
    right--;

    if(top<=bottom)
    {
      //print bottom --> right to left
    for(i=right;i>=left;i-=1)
        printf("%d ",arr[bottom][i]);
    bottom-=1;
    }

     if(left<=right)
     {
        //print left --> bottom to top
    for(i=bottom;i>=top;i-=1)
        printf("%d ",arr[i][left]);
     left+=1;
     }


    }

    return 0;
}
