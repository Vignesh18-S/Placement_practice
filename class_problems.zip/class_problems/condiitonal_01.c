
#include<stdio.h>
int main()
{

   /* int data_age;
    printf("Age must be less than 100\n");
    scanf("%d",&data_age);
    if(data_age<=100 && data_age>=0)      // 100
       printf("valid age is : %d",data_age);
    else
      printf("Age is not valid");*/

    char ch;
    scanf("%c",&ch);
    if(ch>='A' && ch<='Z')  // ch>='0' && ch<='9'
        printf("Upper case");
    else
        printf("Not");
    return 0;
}

