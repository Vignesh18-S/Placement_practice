#include<stdio.h>
int main()
{
    int num,row,col,space,star;
    scanf("%d",&num);
    for(row=1;row<=num;printf("\n"),row+=1)
    {
        //space
        for(space=1;space<=num-row;space+=1)
            printf("   ");

        //star
        for(star=1;star<=row;star+=1)
            printf(" * ");
    }

    return 0;
}
