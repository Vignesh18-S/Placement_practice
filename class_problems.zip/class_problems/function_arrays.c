#include<stdio.h>
int sum_of_array(int *num,int size)
{
   int itr,sum=0;
   for(itr=0;itr<size;itr+=1)
    sum += num[itr];

    return sum;
}
int main()
{
     int size;
     scanf("%d",&size);
     int arr[size],itr;
     for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);

     int sum =sum_of_array(arr,size);
     printf("sum of the array is  : %d",sum);

    return 0;
}
