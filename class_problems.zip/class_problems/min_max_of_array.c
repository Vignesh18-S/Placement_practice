

#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    int arr[size],itr;
    //array's input
    for(itr=0;itr<size;scanf("%d",&arr[itr]),itr+=1);
    int max = arr[0],min = arr[0];
    for(itr=1;itr<size;itr+=1)
    {
        if(max < arr[itr])
            max=arr[itr];
        if(min > arr[itr])
            min = arr[itr];
    }
    printf("Maximum value is : %d",max);
    printf("Minimum value is : %d",min);



    return 0;
}
