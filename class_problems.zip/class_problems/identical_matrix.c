#include<stdio.h>
int main()
{
   int row,col;
   scanf("%d%d",&row,&col);
   int arr1[row][col],arr2[row][col];
   int i,j;
   // array 1 input
   for(i=0;i<row;i+=1)
   {
       for(j=0;j<col;j+=1)
          scanf("%d",&arr1[i][j]);
   }

   //array 2 input
    for(i=0;i<row;i+=1)
   {
       for(j=0;j<col;j+=1)
          scanf("%d",&arr2[i][j]);
   }
   //equal or not

   for(i=0;i<row;i+=1)
   {
       for(j=0;j<col;j+=1)
       {
           if(arr1[i][j] != arr2[i][j])
              break;
       }
       if(j<col)
         break;
   }
   printf("%d",i);
   if(i<row)
     printf("Not equal");
   else
     printf("Equal");


    return 0;
}

