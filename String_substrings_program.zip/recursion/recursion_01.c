// print n natural numbers using recursion
#include<stdio.h>
int natural_no(int num) //5   // function
{
    if(num<=0)
        return 0;
    //natural_no(num-1);
    printf("%d ",num);
    natural_no(num-1); // recursice call
    natural_no(num-1);
    natural_no(num-1);
    natural_no(num-1);

}
int main()
{
    int num;
    scanf("%d",&num);
    printf("\nreturned value is%d",natural_no(num));  // call

}
