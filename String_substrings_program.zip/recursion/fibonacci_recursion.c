#include<stdio.h>
int fibo(int n)
{
    if(n==0)
         return 0;
    else if(n==1 || n==2)
         return 1;

    return fibo(n-1) + fibo(n-2);
}
int main()
{
    int num;
    scanf("%d",&num);
    int itr;
    for(itr=1;itr<=num;itr+=1)
        printf("%d ",fibo(itr));
}
