#include<stdio.h>
#include<string.h>
void reverse_string(char *str)
{
    int i=0;
    int len=strlen(str);
    char temp;
    while(i < len-i-1)
    {
        temp = str[i];
        str[i] = str[len-1-i];
        str[len-1-i] = temp;

        i++;
    }
}
int main()
{
    int size,len;
    scanf("%d%d",&size,&len);
    char str[size][len];
    int itr;
    for(itr=0;itr<size;itr+=1)
    {
        scanf("%s",str[itr]);
    }

    /*
    //2d string reverse
     for(itr=size-1;itr>=0;itr-=1)
    {
        printf("%s\n",str[itr]);
    }*/

    // word by word reverse
    for(itr=0;itr<size;itr+=1)
    {
        reverse_string(str[itr]);
    }

    for(itr=0;itr<size;itr+=1)
        printf("%s ",str[itr]);



    return 0;
}
