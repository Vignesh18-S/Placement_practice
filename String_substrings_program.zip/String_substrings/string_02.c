#include<stdio.h>
int main()
{
    char str[100];
    scanf("%s",str);
    //printf("%s",str); //read as string
    int itr;
    /*for(itr=0;str[itr]!='\0';itr+=1) //read as char
    {
        printf("%c ,",str[itr]);
    }*/
    int count=0;
    for(itr=0;str[itr]!='\0';itr++)
    {
        if(str[itr]>='A' && str[itr]<='Z')
            count++;
    }
      printf("upper case count is %d",count);



}
