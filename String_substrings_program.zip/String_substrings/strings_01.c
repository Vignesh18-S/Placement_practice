#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    char str[size+1];
    scanf("%[^\n]",str); //white space allowed
   // scanf("%s",str);   // white space not allowed
    printf("%s",str);

    return 0;
}
