#include<stdio.h>
#include<stdbool.h>
int main()
{
   char str[100];
   scanf("%[^\n]",str);
   int itr=0,s_ind,e_ind,i;
   char temp;
   while(true)
   {
       s_ind = itr;
       e_ind = s_ind;
       for(i=s_ind;str[i]!=' ' && str[i]!='\0';i+=1);
       e_ind = i-1;

       while(s_ind < e_ind){
       temp = str[s_ind];
       str[s_ind] = str[e_ind];
       str[e_ind] = temp;

       s_ind+=1;
       e_ind-=1;
       }
       if(str[i]=='\0')
          break;
       itr = i+1;

   }

   printf("%s",str);

    return 0;
}
