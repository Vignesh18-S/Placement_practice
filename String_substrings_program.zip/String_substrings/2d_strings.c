#include<stdio.h>
#include<stdbool.h>
#include<string.h>
bool ispalindrome(char *str)
{
    int i=0;
    int len = strlen(str);
    while(i < len-1-i)
    {
        if(str[i] != str[len-1-i])
            return false;
        i++;

    }
    return true;
}
int main()
{
    /*char str[3][10]={"hello","world","welcome"};
    for(int itr=0;itr<3;itr+=1)
       printf("%s\n",str[itr]);*/

       int size,len;
       scanf("%d%d",&size,&len);
       char str[size][len];
       int itr;
       for(itr=0;itr<size;itr+=1)
       {
           scanf("%s",str[itr]);

       }
       for(itr=0;itr<size;itr+=1)
       {
          if(ispalindrome(str[itr]))
             printf("%s ",str[itr]);
       }



}
