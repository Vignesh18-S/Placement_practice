#include<stdio.h>
#include<string.h>
int main()
{
    char str[100];
    scanf("%[^\n]",str);
    int itr=0;
    int len = strlen(str);
    while(itr < len-1-itr)
    {
        if(str[itr]!=str[len-1-itr])
            break;
        itr+=1;
    }
    if(itr < len-1-itr)
        printf("Not palindrome");
    else
        printf("Palindrome");
}
