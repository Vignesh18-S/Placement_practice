#include<stdio.h>
#include<string.h>
int main()
{
   /* char str1[]="Sri ramakrishna engineering college";

    length without inbuild
    int itr;
    for(itr=0;str1[itr];itr+=1);
    printf("length is %d",itr);

    //copy without inbuild
    char str2[100];
    int itr;
    for(itr=0;str1[itr];itr+=1)
    {
        str2[itr] = str1[itr];
    }
    printf("%s\n%s",str1,str2);*/

    /*
    char str1[]="ramakrishna";
    char str2[]="college";
    /*char str3[1000];
    printf("%s",strcat(str1,str2));

    //without function
    int len1 = strlen(str1);
    int len2 = strlen(str2);
    char res[len1+len2+1];
    int itr;
    for(itr=0;itr<len1+len2;itr+=1)
    {
        if(itr<len1)
            res[itr] = str1[itr];
        else
            res[itr] = str2[itr-len1];
    }
    res[itr] = '\0';
    printf("%s",res);


    //comparison function
    char str1[] = "ramakrishna";
    char str2[] = "ramaKriShna";
    printf("%d",strcmp(str1,str2));
    */

    char str[]="ramakrishna college coimbatore";
    //printf("%s",strrev(str));
    char str1[100];
    int itr,rev_itr=0;
    int len=strlen(str);
    for(itr=len-1;itr>=0;itr-=1)
    {
        str1[rev_itr++] = str[itr];

    }
    str1[rev_itr]='\0';
    printf("%s",str1);

    if(strcmp(str1,str2)==0)





}
