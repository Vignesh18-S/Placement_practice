#include<stdio.h>
int main()
{
   char str[100];
   scanf("%s\n",str); //ramAkrishna
   int count=0,itr;
   char key_char;
   scanf("%c",&key_char);
   for(itr=0;str[itr];itr+=1)
   {
       if(str[itr]==key_char)
        break;

   }
   if(str[itr]==key_char)
    printf("Found");
   else
    printf("Not found");

 return 0;
}
