#include<stdio.h>
int main()
{
   char str[100];
   scanf("%s",str); //ramAkrishna
   int count=0,itr;
   for(itr=0;str[itr]!='\0';itr+=1)
   {
       if(!(str[itr]=='a' || str[itr]=='e' || str[itr]=='i' || str[itr]=='o' || str[itr]=='u' ||
          str[itr]=='A' || str[itr]=='E' || str[itr]=='I' || str[itr]=='O' || str[itr]=='U'))
            count++;

   }
   printf("%d",count);




 return 0;
}
