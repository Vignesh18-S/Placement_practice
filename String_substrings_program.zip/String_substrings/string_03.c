#include<stdio.h>
#include<string.h>
int main()
{
    /* //length
    char str[5]="srec";
    //scanf("%s",str);
    printf("%d",sizeof(str));*/

    /*  //string is mutable
    char str[]="Sri ramakrishna college";
    printf("%u",&str);
    printf("%s",str);
    str[8]='R';
    printf("%s",str);
    printf("%u",&str);*/

    char str1[100]="ramakrishna";
    char str2[100];
    strcpy(str2,str1);
    printf("%s",str2);

}
